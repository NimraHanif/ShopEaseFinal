import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Alert,
  PermissionsAndroid,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useMutation } from '@apollo/client/react';
import Geolocation from '@react-native-community/geolocation';
import { CREATE_ADDRESS_MUTATION, ADDRESSES_QUERY } from '../../api/graphql/addresses.graphql';

const schema = yup.object({
  label: yup.string().required('Label is required (e.g. Home, Work)'),
  recipientName: yup.string().required('Recipient name is required'),
  phoneNumber: yup.string().required('Phone number is required'),
  addressLine1: yup.string().required('Address line 1 is required'),
  addressLine2: yup.string().optional(),
  city: yup.string().required('City is required'),
  state: yup.string().required('State/Province is required'),
  postalCode: yup.string().required('Postal code is required'),
  country: yup.string().required('Country is required'),
});

type FormData = yup.InferType<typeof schema>;

// Address
export default function AddAddressScreen({ navigation }: any) {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationDenied, setLocationDenied] = useState(false);
  const [fetchingLocation, setFetchingLocation] = useState(false);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({ resolver: yupResolver(schema) });

  const [createAddress, { loading }] = useMutation(CREATE_ADDRESS_MUTATION, {
    refetchQueries: [{ query: ADDRESSES_QUERY }],
    awaitRefetchQueries: true,
  });

  const requestLocation = async () => {
    setFetchingLocation(true);
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Permission',
            message: 'Allow location access to auto-fill your delivery coordinates.',
            buttonPositive: 'Allow',
            buttonNegative: 'Deny',
          }
        );

        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
          setLocationDenied(true);
          setFetchingLocation(false);
          Alert.alert(
            'Permission Denied',
            'Location permission was denied. You can manually enter your address details in the form below.',
            [{ text: 'OK' }]
          );
          return;
        }
      }

      Geolocation.getCurrentPosition(
        (position) => {
          setCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
          setLocationDenied(false);
          setFetchingLocation(false);
          Alert.alert('Success', 'Location coordinates attached to your address!');
        },
        (error) => {
          setLocationDenied(true);
          setFetchingLocation(false);
          Alert.alert(
            'Location Error',
            error.message || 'Could not fetch your current location. Please enter your address manually.'
          );
        },
        { enableHighAccuracy: false, timeout: 15000, maximumAge: 10000 }
      );
    } catch (err: any) {
      setLocationDenied(true);
      setFetchingLocation(false);
      Alert.alert('Permission Error', 'Unable to request location. Please fill in the address manually.');
    }
  };

  const onSubmit = async (formData: FormData) => {
    try {
      await createAddress({
        variables: {
          label: formData.label,
          recipientName: formData.recipientName,
          phoneNumber: formData.phoneNumber,
          address: formData.addressLine1,
          city: formData.city,
          country: formData.country,
          postalCode: formData.postalCode,
          default: (formData as any).isDefault ?? (formData as any).default ?? false,
        },
      });
      navigation.goBack();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to save address.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Add Address</Text>

      <TouchableOpacity
        style={[styles.locationBtn, fetchingLocation && styles.disabledBtn]}
        onPress={requestLocation}
        disabled={fetchingLocation}
      >
        <Text style={styles.locationBtnText}>
          {fetchingLocation ? 'Fetching Location...' : '📍 Use Current Location'}
        </Text>
      </TouchableOpacity>

      {coords && (
        <Text style={styles.coordsText}>
          📍 Coordinates: {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
        </Text>
      )}

      {locationDenied && (
        <View style={styles.warningBox}>
          <Text style={styles.warningText}>
            ⚠️ Location permission is denied or location services are disabled. You can still manually enter your full address below to save it.
          </Text>
        </View>
      )}

      {(
        [
          ['label', 'Label (e.g. Home, Work)'],
          ['recipientName', 'Recipient Name'],
          ['phoneNumber', 'Phone Number'],
          ['addressLine1', 'Address Line 1'],
          ['addressLine2', 'Address Line 2 (optional)'],
          ['city', 'City'],
          ['state', 'State / Province'],
          ['postalCode', 'Postal Code'],
          ['country', 'Country'],
        ] as [keyof FormData, string][]
      ).map(([name, placeholder]) => (
        <View key={name}>
          <Controller
            control={control}
            name={name}
            render={({ field: { onChange, value } }) => (
              <TextInput
                style={styles.input}
                placeholder={placeholder}
                value={value ?? ''}
                onChangeText={onChange}
              />
            )}
          />
          {errors[name] && <Text style={styles.error}>{errors[name]?.message}</Text>}
        </View>
      ))}

      {loading ? (
        <ActivityIndicator size="large" color="#2ecc71" style={{ marginTop: 20 }} />
      ) : (
        <View style={styles.submitContainer}>
          <Button title="Save Address" onPress={() => handleSubmit(onSubmit)()} color="#2ecc71" />
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 16, textAlign: 'center', color: '#333' },
  locationBtn: {
    backgroundColor: '#3498db',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  disabledBtn: { backgroundColor: '#bdc3c7' },
  locationBtnText: { color: '#fff', fontWeight: '600', fontSize: 15 },
  coordsText: { textAlign: 'center', marginTop: 4, marginBottom: 10, color: '#2ecc71', fontWeight: '500' },
  warningBox: {
    backgroundColor: '#fff3cd',
    borderColor: '#ffeeba',
    borderWidth: 1,
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
  },
  warningText: { textAlign: 'center', color: '#856404', fontSize: 13, lineHeight: 18 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginTop: 10,
    fontSize: 15,
    backgroundColor: '#fafafa',
  },
  error: { color: '#e74c3c', fontSize: 12, marginTop: 2 },
  submitContainer: { marginTop: 20, marginBottom: 30 },
});